﻿
Param ([switch]$NoWarning,[switch]$Debug)

If ($Debug) {
    #enable debug messages if -debug is specified
    $debugPreference="Continue"
}

If ($NoWarning) {
    #turn off warning messages
    $WarningPreference="SilentlyContinue"
}

if (! (Get-Module ActiveDirectory)){
			Import-Module ActiveDirectory -ErrorAction SilentlyContinue -WarningAction SilentlyContinue
			Write-Host ("[SUCCESS]") ("ActiveDirectory Powershell Module Loaded")
			Write-Verbose -Message "Active directory Module import successfully"
		}

else{
			Write-Host ("[INFO]") ("ActiveDirectory Powershell Module Already Loaded")
			Write-Verbose -Message "ActiveDirectory Powershell Module Already Loaded"
		}


function Ping-Host {
  Param([string]$computername=$(Throw "You must Enter Computername."))
  
  Write-Debug "In Ping-Host function"
  
  $query="Select * from Win32_PingStatus where address='$computername'"
  
  $wmi=Get-WmiObject -query $query
  write $wmi
}



#Generated Form Function
function GenerateForm {

#region Import the Assemblies
Write-Debug "Loading Assemblies"
[reflection.assembly]::loadwithpartialname("System.Drawing") | Out-Null
[reflection.assembly]::loadwithpartialname("System.Windows.Forms") | Out-Null
[reflection.Assembly]::LoadWithPartialName("system.windows.messagebox")| Out-Null
[System.Windows.Forms.Application]::EnableVisualStyles();
[System.Reflection.Assembly]::LoadWithPartialName('Microsoft.VisualBasic') | Out-Null
#endregion

#region Generated Form Objects
Write-Debug "Creating form objects"
$form1 = New-Object System.Windows.Forms.Form
$lblRefreshInterval = New-Object System.Windows.Forms.Label
$numInterval = New-Object System.Windows.Forms.NumericUpDown
$btnQuit = New-Object System.Windows.Forms.Button
$btnGo = New-Object System.Windows.Forms.Button
$dataGridView = New-Object System.Windows.Forms.DataGridView
$label2 = New-Object System.Windows.Forms.Label
$statusBar = New-Object System.Windows.Forms.StatusBar
$timer1 = New-Object System.Windows.Forms.Timer
$btnhelp = New-Object System.Windows.Forms.Button
$btngetDC = New-Object System.Windows.Forms.Button
#endregion Generated Form Objects

$vbmsg = new-object -comobject wscript.shell

#----------------------------------------------
#Generated Event Script Blocks
#----------------------------------------------

$GetStatus= 
{

 Trap {
    	Write-Debug "Error trapped in GetStatus script block"
    	Write-Warning $_.Exception.message
        Continue
    }
    
    #stop the timer while data is refreshed
    Write-Debug "Stop the timer"
    $timer1.stop()

    #Domain controllersselecting
    Write-Debug ("Getting content Domain Conrtollers")
    $DC = Get-ADDomainController
    
    #clear the table
    $dataGridView.DataSource=$Null
  
    $form1.Refresh
        
        #create an array for griddata
        Write-Debug "Create `$griddata"
        $griddata=@()
        
        

      foreach ($Dcserver in $dc.hostname)
		{
			if (Test-Connection -ComputerName $Dcserver -Count 4 -Quiet)
			{
				$statusBar.Text = "Please Wait"
				try
				{
					#set ping = ok 
					Write-Verbose "setping = OK"
					
					$setping = "OK"
					
					# Netlogon Service Status  
					
					Write-Verbose "checking status of netlogon"
					
					$DcNetlogon = Get-Service -ComputerName $Dcserver -Name "Netlogon" -ErrorAction SilentlyContinue
					
					if ($DcNetlogon.Status -eq "Running")
					{
						
						$setnetlogon = "OK"
						
					}
					
					else
					{
						
						$setnetlogon = "NOT OK"
						
					}
					
					#NTDS Service Status
					
					Write-Verbose "checking status of NTDS"
					
					$dcntds = Get-Service -ComputerName $Dcserver -Name "NTDS" -ErrorAction SilentlyContinue
					
					if ($dcntds.Status -eq "running")
					{
						
						$setntds = "OK"
						
					}
					
					else
					{
						
						$setntds = "NO OK"
						
					}
					
					#DNS Service Status 
					
					Write-Verbose "checking status of DNS"
					
					$dcdns = Get-Service -ComputerName $Dcserver -Name "DNS" -ea SilentlyContinue
					
					if ($dcdns.Status -eq "running")
					{
						$setdcdns = "OK"
					}
					
					else
					{
						
						$setdcdns = "NOT OK"
						
					}
					
					#Dcdiag netlogons "Checking now"
					
					Write-Verbose "Checking Status of netlogns"
					
					$dcdiagnetlogon = dcdiag /test:netlogons /s:$dcserver
					if ($dcdiagnetlogon -match "passed test NetLogons")
					{
						
						$setdcdiagnetlogon = "OK"
						
					}
					else
					{
						
						$setdcdiagnetlogon = "NOT OK"
						
					}
					
					#Dcdiag services check
					
					Write-Verbose "Checking status of DCdiag Services"
					
					$dcdiagservices = dcdiag /test:services /s:$dcserver
					
					if ($dcdiagservices -match "passed test services")
					{
						
						$setdcdiagservices = "OK"
						
					}
					else
					{
						
						$setdcdiagservices = "NOT OK"
						
					}
					
					
				#Dcdiag Replication Check
					
					Write-Verbose "Checking status of DCdiag Replication"
					
					$dcdiagreplications = dcdiag /test:Replications /s:$dcserver
					
					if ($dcdiagreplications -match "passed test Replications")
					{
						
						$setdcdiagreplications = "OK"
						
					}
					else
					{
						
						$setdcdiagreplications = "NOT OK"
						
					} 
					
					#Dcdiag FSMOCheck Check
					
					Write-Verbose "Checking status of DCdiag FSMOCheck"
					
					$dcdiagFsmoCheck = dcdiag /test:FSMOCheck /s:$dcserver
					
					if ($dcdiagFsmoCheck -match "passed test FsmoCheck")
					{
						
						$setdcdiagFsmoCheck = "OK"
						
					}
					else
					{
						
						$setdcdiagFsmoCheck = "NOT OK"
						
					}
				
					#Dcdiag Advertising Check
					
					Write-Verbose "Checking status of DCdiag Advertising"
					
					$dcdiagAdvertising = dcdiag /test:Advertising /s:$dcserver
					
					if ($dcdiagAdvertising -match "passed test Advertising")
					{
						
						$setdcdiagAdvertising = "OK"
						
					}
					else
					{
						
						$setdcdiagAdvertising = "NOT OK"
						
					}
					
					$tryok = "OK"
					
				}
				catch
				{
					
					$ErrorMessage = $_.Exception.Message
					
					$richtextbox1.Text = $ErrorMessage
					
				}
				
				if ($tryok -eq "OK")
				{
					
					#new-object Created
					
					$csvObject = New-Object PSObject
					
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "DCName" -value $dcserver
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "Ping" -value $setping
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "Netlogon" -value $setnetlogon
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "NTDS" -value $setntds
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "DNS" -value $setdcdns
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "Dcdiag_netlogons" -value $setdcdiagnetlogon
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "Dcdiag_Services" -value $setdcdiagservices
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "Dcdiag_replications" -value $setdcdiagreplications
			     	Add-Member -inputObject $csvObject -memberType NoteProperty -name "Dcdiag_FSMOCheck" -value $setdcdiagFsmoCheck
					Add-Member -inputObject $csvObject -memberType NoteProperty -name "DCdiag_Advertising" -value $setdcdiagAdvertising
					
					#set DC status 
					$setdcstatus = "ok"
					
				}
				
			}
			else
			{
				#if Server Down
				Write-Verbose "Server Down"
				
				$setdcValue = "$dcserver is down"
              	
                $setdcstatus = "NOT OK"
                			
				Add-Member -inputObject $csvObject -memberType NoteProperty -name "Server_down" -value $setdcValue
				
			}
			#Output of Property
			
		Write-Debug "Adding `$obj to `$griddata"
       
         $griddata+=$csvObject

        Write-Debug "Creating ArrayList"   
       
        $array= New-Object System.Collections.ArrayList
        
        Write-Debug "Adding `$griddata to `$arry"
        $array.AddRange($griddata)
        $DataGridView.DataSource = $array
        #find unpingable computer rows
        Write-Debug "Searching for non-pingable computers"
        $c=$dataGridView.RowCount
        for ($x=0;$x -lt $c;$x++) {
            for ($y=0;$y -lt $dataGridView.Rows[$x].Cells.Count;$y++) {
                $value = $dataGridView.Rows[$x].Cells[$y].Value
                if ($value -eq "NOT OK") {
                #if Pinged cell = No change the row font color
                Write-Debug "Changing color on row $x"
                $dataGridView.rows[$x].DefaultCellStyle.Forecolor=[System.Drawing.Color]::FromArgb(255,255,0,0)
                }
            }
     }
        
        Write-Debug "Setting status bar text"
        $statusBar.Text=("Ready. Last updated {0}" -f (Get-Date))

   }

    #set the timer interval
    $interval=$numInterval.value -as [int]
    Write-Debug "Interval is $interval"
    #interval must be in milliseconds
    $timer1.Interval = ($interval * 60000) #1 minute time interval
    Write-Debug ("Timer interval calculated at {0} milliseconds" -f $timer1.Interval )
    #start the timer
    Write-Debug "Starting timer"
    $timer1.Start()
    
    Write-Debug "Refresh form"
    $form1.Refresh()
}

$helpclick = 
{


$helptxt =  @"
    
    This Script will check the helath of AD . if it not ok it will show in red colours.

    it will auto Refresh after interval time 

    TO stop Script click on close

"@
  
$vbpop = $vbmsg.popup($helptxt)
   
   }

$getdc = 
{

$dcs = Get-ADDomainController | Select-Object Hostname | Out-String 



$vbpop = $vbmsg.popup($dcs)

}
$Quit= 
{
    Write-Debug "closing the form"
    $form1.Close()
} #End Quit scriptblock

#----------------------------------------------
#region Generated Form Code
$form1.Name = 'form1'
$form1.Text = 'AD Health Check'
$form1.DataBindings.DefaultDataSourceUpdateMode = 0
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 890
$System_Drawing_Size.Height = 359
$form1.ClientSize = $System_Drawing_Size
$form1.StartPosition = 1
$form1.BackColor = [System.Drawing.Color]::FromArgb(255,185,209,234)

$lblRefreshInterval.Text = 'Refresh Interval (min)'

$lblRefreshInterval.DataBindings.DefaultDataSourceUpdateMode = 0
$lblRefreshInterval.TabIndex = 10
$lblRefreshInterval.TextAlign = 64
#$lblRefreshInterval.Anchor = 9
$lblRefreshInterval.Name = 'lblRefreshInterval'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 128
$System_Drawing_Size.Height = 23
$lblRefreshInterval.Size = $System_Drawing_Size
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 440
$System_Drawing_Point.Y = 28
$lblRefreshInterval.Location = $System_Drawing_Point

$form1.Controls.Add($lblRefreshInterval)

#$numInterval.Anchor = 9
$numInterval.DataBindings.DefaultDataSourceUpdateMode = 0
$numInterval.Name = 'numInterval'
$numInterval.Value = "20"
$numInterval.TabIndex = 9
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 51
$System_Drawing_Size.Height = 20
$numInterval.Size = $System_Drawing_Size
$numInterval.Maximum = 60
$numInterval.Minimum = 1
$numInterval.Increment = 2
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 575
$System_Drawing_Point.Y = 30
$numInterval.Location = $System_Drawing_Point
# $numInterval.add_ValueChanged($GetStatus)

$form1.Controls.Add($numInterval)


$btnQuit.UseVisualStyleBackColor = $True
$btnQuit.Text = 'Close'

$btnQuit.DataBindings.DefaultDataSourceUpdateMode = 0
$btnQuit.TabIndex = 2
$btnQuit.Name = 'btnQuit'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 75
$System_Drawing_Size.Height = 23
$btnQuit.Size = $System_Drawing_Size
#$btnQuit.Anchor = 9
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 175
$System_Drawing_Point.Y = 30
$btnQuit.Location = $System_Drawing_Point
$btnQuit.add_Click($Quit)

$form1.Controls.Add($btnQuit)


$btnGo.UseVisualStyleBackColor = $True
$btnGo.Text = 'Start'

$btnGo.DataBindings.DefaultDataSourceUpdateMode = 0
$btnGo.TabIndex = 1
$btnGo.Name = 'btnGo'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 75
$System_Drawing_Size.Height = 23
$btnGo.Size = $System_Drawing_Size
#$btnGo.Anchor = 9
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 50
$System_Drawing_Point.Y = 30
$btnGo.Location = $System_Drawing_Point
$btnGo.add_Click($GetStatus)

$form1.Controls.Add($btnGo)

$btnhelp.UseVisualStyleBackColor = $True
$btnhelp.Text = 'Help'

$btnhelp.DataBindings.DefaultDataSourceUpdateMode = 0
$btnhelp.TabIndex = 1
$btnhelp.Name = 'btnhelp'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 50
$System_Drawing_Size.Height = 23
$btnhelp.Size = $System_Drawing_Size
#$btnGo.Anchor = 9
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 830
$System_Drawing_Point.Y = 10
$btnhelp.Location = $System_Drawing_Point

$btnhelp.add_Click($helpclick)

$form1.Controls.Add($btnhelp)

$btngetDC.UseVisualStyleBackColor = $True
$btngetDC.Text = 'Get-DC'

$btngetDC.DataBindings.DefaultDataSourceUpdateMode = 0
$btngetDC.TabIndex = 1
$btngetDC.Name = 'Get-DC'
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 50
$System_Drawing_Size.Height = 23
$btnhelp.Size = $System_Drawing_Size
#$btnGo.Anchor = 9
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 300
$System_Drawing_Point.Y = 30
$btngetDC.Location = $System_Drawing_Point

$btngetDC.add_Click($getdc)

$form1.Controls.Add($btngetDC)

$dataGridView.RowTemplate.DefaultCellStyle.ForeColor = [System.Drawing.Color]::FromArgb(255,0,128,0)
$dataGridView.Name = 'dataGridView'
$dataGridView.DataBindings.DefaultDataSourceUpdateMode = 0
$dataGridView.ReadOnly = $True
$dataGridView.AllowUserToDeleteRows = $False
$dataGridView.RowHeadersVisible = $False
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 870
$System_Drawing_Size.Height = 260
$dataGridView.Size = $System_Drawing_Size
$dataGridView.TabIndex = 8
$dataGridView.Anchor = 15
$dataGridView.AutoSizeColumnsMode = 16



$dataGridView.AllowUserToAddRows = $False
$dataGridView.ColumnHeadersHeightSizeMode = 2
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 13
$System_Drawing_Point.Y = 70
$dataGridView.Location = $System_Drawing_Point
$dataGridView.AllowUserToOrderColumns = $True
$dataGridView.add_CellContentDoubleClick($LaunchCompMgmt)
#$dataGridView.AutoResizeColumns([System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells]::AllCells)
#$DataGridViewAutoSizeColumnsMode.AllCells

$form1.Controls.Add($dataGridView)


$statusBar.Name = 'statusBar'
$statusBar.DataBindings.DefaultDataSourceUpdateMode = 0
$statusBar.TabIndex = 4
$System_Drawing_Size = New-Object System.Drawing.Size
$System_Drawing_Size.Width = 428
$System_Drawing_Size.Height = 22
$statusBar.Size = $System_Drawing_Size
$System_Drawing_Point = New-Object System.Drawing.Point
$System_Drawing_Point.X = 0
$System_Drawing_Point.Y = 337
$statusBar.Location = $System_Drawing_Point
$statusBar.Text = 'Ready'

$form1.Controls.Add($statusBar)


#endregion Generated Form Code

Write-Debug "Adding script block to timer"
#add the script block to execute when the timer interval expires
$timer1.add_Tick($GetStatus)

#Show the Form
Write-Debug "ShowDialog()"
$form1.ShowDialog()| Out-Null

} #End Function

#Call the Function
Write-Debug "Call GenerateForm"
GenerateForm

